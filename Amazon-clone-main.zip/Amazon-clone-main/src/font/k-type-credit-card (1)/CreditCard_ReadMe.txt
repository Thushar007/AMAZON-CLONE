
=== CREDIT CARD ===


Keith Bates / K-Type © 2009 (version 1.01)
www.k-type.com    -    info@k-type.com

Credit Card is an ALL CAPITALS font for simulating bank cards (and to suggest a context of banking, finance, membership or security).

The number keys produce the bigger, squarer digits of the 16 figure card number.

There is no lowercase in this font. Instead, the small numerals used for validity dates fill the lowercase letter keys, 1 > 9 being at a > i.

In deference to their functional origins, most characters are monospaced and devoid of pair kerning. Also, many of the accented capital letters are reduced in vertical size to help accommodate the diacritic.

Emboss in Photoshop to simulate raised type - Layer > Layer Style > Bevel and Emboss

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------