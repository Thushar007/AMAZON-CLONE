const AddOrder = (data) => {
    return {
      type: "ADD_ORDER",
      data: data,
    };

  };
  
  export { AddOrder};
  